# photograph
前端界面调用本地摄像头，然后拍照结束后可以截取预览，最后将结果以base64提交到后台
这里我修改了一个jquery插件，把摄像头拍照的功能融合了进去。

提交到后台时是提交一个base64字符，在后台再将base64字符转换为图片保存。。

效果图：
![Image text](https://github.com/HL-Guitar/photograph//raw/master/1.png)
